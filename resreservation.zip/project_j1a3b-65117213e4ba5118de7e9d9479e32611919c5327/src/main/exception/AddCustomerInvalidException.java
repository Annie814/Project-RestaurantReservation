package exception;

public class AddCustomerInvalidException extends RuntimeException {
    public AddCustomerInvalidException(String s) {
        super(s);
    }

}