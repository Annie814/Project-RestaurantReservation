package ui;

public class UIMain {
    public static void main(String[] args) {
        new UserInterface().setVisible(true);
    }
}
